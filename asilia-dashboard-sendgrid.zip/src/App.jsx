import React from 'react'
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom'
import Login from './components/Login'
import Dashboard from './components/Dashboard'
import { auth } from './firebase'
import { onAuthStateChanged } from 'firebase/auth'

function App(){
  const [user, setUser] = React.useState(null)
  React.useEffect(()=>{
    const unsub = onAuthStateChanged(auth, u=> setUser(u))
    return ()=> unsub()
  },[])

  return (
    <Router>
      <Routes>
        <Route path="/login" element={<Login/>} />
        <Route path="/app" element={user ? <Dashboard user={user}/> : <Navigate to="/login"/>} />
        <Route path="/" element={<Navigate to="/app"/>} />
      </Routes>
    </Router>
  )
}

export default App
