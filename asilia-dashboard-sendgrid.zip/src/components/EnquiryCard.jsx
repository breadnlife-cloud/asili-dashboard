import React from 'react'
import { doc, updateDoc } from 'firebase/firestore'
import { db } from '../firebase'

export default function EnquiryCard({e}){
  const [expanded, setExpanded] = React.useState(false)
  const toggleStatus = async () =>{
    const d = doc(db,'enquiries', e.id)
    const next = e.status === 'New' ? 'In Progress' : e.status === 'In Progress' ? 'Closed' : 'Closed'
    await updateDoc(d, { status: next })
  }

  return (
    <div className="bg-white p-4 rounded shadow">
      <div className="flex justify-between">
        <div>
          <div className="font-semibold">{e.name} — <span className="text-sm">{e.email}</span></div>
          <div className="text-xs text-gray-500">{new Date(e.createdAt?.seconds ? e.createdAt.seconds*1000 : e.createdAt).toLocaleString()}</div>
        </div>
        <div className="text-sm">{e.status || 'New'}</div>
      </div>
      <div className="mt-2 text-sm">{e.message?.slice(0,200)}{e.message?.length>200 && '...'}</div>
      <div className="mt-3 flex gap-2">
        <button onClick={()=>setExpanded(!expanded)} className="text-sm underline">{expanded? 'Hide':'Open'}</button>
        <button onClick={toggleStatus} className="text-sm underline">Toggle Status</button>
      </div>
      {expanded && (
        <div className="mt-3 border-t pt-3">
          <div className="mb-2"><strong>Message:</strong><div className="whitespace-pre-wrap">{e.message}</div></div>
          <div><strong>Assigned:</strong> {e.department || 'Unassigned'}</div>
          <AssignSection enquiryId={e.id} current={e.department}/>
        </div>
      )}
    </div>
  )
}

function AssignSection({enquiryId, current}){
  const [dept, setDept] = React.useState(current||'')
  const assign = async ()=>{
    const dref = doc(db,'enquiries',enquiryId)
    await updateDoc(dref, { department: dept })
  }
  return (
    <div className="mt-2 space-y-2">
      <select value={dept} onChange={e=>setDept(e.target.value)} className="p-2 border rounded w-full">
        <option value="">Unassigned</option>
        <option value="Sales">Sales</option>
        <option value="Operations">Operations</option>
        <option value="Marketing">Marketing</option>
      </select>
      <div className="flex gap-2">
        <button onClick={assign} className="px-3 py-1 rounded bg-green-600 text-white text-sm">Assign</button>
      </div>
    </div>
  )
}
