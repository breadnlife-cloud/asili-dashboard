import React from 'react'
import { signInWithEmailAndPassword } from 'firebase/auth'
import { auth } from '../firebase'

export default function Login(){
  const [email, setEmail] = React.useState('')
  const [password, setPassword] = React.useState('')
  const [err, setErr] = React.useState(null)
  const handleLogin = async e =>{
    e.preventDefault()
    try{ await signInWithEmailAndPassword(auth, email, password) }
    catch(e){ setErr(e.message) }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50">
      <form onSubmit={handleLogin} className="w-full max-w-md bg-white p-6 rounded-2xl shadow">
        <h2 className="text-xl font-semibold mb-4">Asili Africa - Admin Login</h2>
        {err && <div className="text-sm text-red-600 mb-2">{err}</div>}
        <input value={email} onChange={e=>setEmail(e.target.value)} placeholder="Email" className="w-full mb-3 p-2 border rounded" />
        <input value={password} onChange={e=>setPassword(e.target.value)} placeholder="Password" type="password" className="w-full mb-4 p-2 border rounded" />
        <button className="w-full py-2 rounded bg-blue-600 text-white">Sign in</button>
      </form>
    </div>
  )
}
