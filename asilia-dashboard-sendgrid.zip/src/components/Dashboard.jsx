import React from 'react'
import EnquiryList from './EnquiryList'
import { signOut } from 'firebase/auth'
import { auth } from '../firebase'

export default function Dashboard({user}){
  return (
    <div className="min-h-screen bg-gray-100">
      <header className="flex justify-between items-center p-4 bg-white shadow">
        <div className="text-lg font-bold">Asili Africa - Enquiries</div>
        <div className="flex items-center gap-3">
          <div className="text-sm">{user.email}</div>
          <button onClick={()=>signOut(auth)} className="text-sm underline">Sign out</button>
        </div>
      </header>
      <main className="p-6">
        <EnquiryList/>
      </main>
    </div>
  )
}
