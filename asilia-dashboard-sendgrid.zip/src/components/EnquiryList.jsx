import React from 'react'
import { collection, query, orderBy, onSnapshot, where } from 'firebase/firestore'
import { db } from '../firebase'
import EnquiryCard from './EnquiryCard'

export default function EnquiryList(){
  const [enquiries, setEnquiries] = React.useState([])
  const [filter, setFilter] = React.useState('all')

  React.useEffect(()=>{
    let q = query(collection(db,'enquiries'), orderBy('createdAt','desc'))
    if(filter !== 'all') q = query(collection(db,'enquiries'), where('department','==',filter), orderBy('createdAt','desc'))
    const unsub = onSnapshot(q, snap =>{
      const docs = snap.docs.map(d=>({id:d.id, ...d.data()}))
      setEnquiries(docs)
    })
    return ()=>unsub()
  },[filter])

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
      <aside className="md:col-span-1">
        <div className="bg-white p-4 rounded shadow">
          <h3 className="font-semibold mb-2">Filters</h3>
          <select value={filter} onChange={e=>setFilter(e.target.value)} className="w-full p-2 border rounded">
            <option value="all">All</option>
            <option value="Sales">Sales</option>
            <option value="Operations">Operations</option>
            <option value="Marketing">Marketing</option>
          </select>
        </div>
      </aside>

      <section className="md:col-span-2">
        <div className="space-y-3">
          {enquiries.map(eq=> <EnquiryCard key={eq.id} e={eq} />)}
          {enquiries.length===0 && <div className="p-6 bg-white rounded shadow">No enquiries found.</div>}
        </div>
      </section>
    </div>
  )
}
