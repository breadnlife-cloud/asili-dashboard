const functions = require("firebase-functions");
const admin = require("firebase-admin");
const sgMail = require("@sendgrid/mail");

admin.initializeApp();
sgMail.setApiKey(functions.config().sendgrid.key);

exports.receiveEnquiry = functions.https.onRequest(async (req, res) => {
  if (req.method !== "POST") {
    return res.status(405).send("Method Not Allowed");
  }

  try {
    const data = req.body;

    // Save to Firestore
    const docRef = await admin.firestore().collection("enquiries").add({
      name: data.name,
      email: data.email,
      phone: data.phone,
      message: data.message,
      department: data.department || "General",
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
      status: "New"
    });

    // Send email notification
    const msg = {
      to: [
        "info@asiliafricaexpeditions.com",
        "sales@asiliafricaexpeditions.com",
        "operations@asiliafricaexpeditions.com"
      ],
      from: "no-reply@asiliafricaexpeditions.com",
      subject: `New Enquiry from ${data.name}`,
      html: `
        <h3>New Website Enquiry Received</h3>
        <p><strong>Name:</strong> ${data.name}</p>
        <p><strong>Email:</strong> ${data.email}</p>
        <p><strong>Phone:</strong> ${data.phone}</p>
        <p><strong>Department:</strong> ${data.department || "General"}</p>
        <p><strong>Message:</strong></p>
        <p>${data.message}</p>
        <hr />
        <p>View in Dashboard: <a href="https://dashboard.asiliafricaexpeditions.com">Open Dashboard</a></p>
      `,
    };

    await sgMail.sendMultiple(msg);

    res.status(200).json({ success: true, id: docRef.id });
  } catch (error) {
    console.error("Error saving enquiry:", error);
    res.status(500).json({ error: error.message });
  }
});
