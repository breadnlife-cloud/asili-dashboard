# Asili Africa Expeditions - Admin Dashboard

This is a React + Tailwind + Firebase admin dashboard scaffold that:
- Receives enquiries from the website and stores them in Firestore
- Lets admins view, filter, search and assign enquiries to departments
- Tracks status (New, In Progress, Closed) and notes
- Supports Firebase Auth (email/password) and simple role-based access (admin, sales, ops, marketing)
- Provides a webhook/cloud-function that your website can call to submit enquiries

## Quick start
1. Install Node.js (14+ recommended) and the Firebase CLI.
2. Create a Firebase project and enable Firestore and Authentication (Email/password).
3. Replace firebase config in `src/firebase.js` with your project values.
4. Install dependencies: `npm install`
5. Run locally: `npm start`
6. Deploy functions: `firebase deploy --only functions`
7. Deploy entire project (if configured with firebase hosting): `firebase deploy`

## Files included
- src/ (React app files)
- functions/index.js (Cloud Function to receive enquiries)
- firestore.rules (suggested Firestore security rules)
- package.json
